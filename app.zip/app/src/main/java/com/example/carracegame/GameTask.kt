package com.example.carracegame

interface GameTask
{
    fun closeGame(mScore:Int)
}